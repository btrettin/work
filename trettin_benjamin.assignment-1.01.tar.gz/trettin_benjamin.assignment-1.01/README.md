## Assignment 1.01 - Dungeon Generation

## SETUP

Run 'make' inside the trettin_benjamin.assignment-1.01 directory to build the project.

## Running Source Code

The dungeon map can be generated using the './map' command. The source code is located inside of the map.c file.

## Notes

The ChangLog file shows all of my commits for this project up to this point.
