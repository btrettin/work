## Assignment 1.01 - Generate Dungeon Map

## SETUP

The 'makefile' is located in the build directory so you will need to go inside of it to run make.

## Running Source Code

The source code is located inside of the map.c file and can be run inside the build directory
with the ./map command.

## Notes
