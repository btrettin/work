void initGame(void);
void StartGame(void);
void closeGame(void);
