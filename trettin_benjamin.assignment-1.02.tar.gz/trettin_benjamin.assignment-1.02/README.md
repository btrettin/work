## Assignment 1.01 - Dungeon Generation

## SETUP

Run 'make' inside the trettin_benjamin.assignment-1.02 directory to build the project.

## Running Source Code

The dungeon map can be generated using the ./run command. The source code is located inside of the map.c and dungeonGame.c files.  

./run --save   

./run --load  

These commands above can be used to save and load the dungeon file found in the .rlg327 directory.

## Notes

The CHANGELOG file shows all of my commits for this project up to this point.
