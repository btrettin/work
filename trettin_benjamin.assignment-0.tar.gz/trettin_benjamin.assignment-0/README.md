
Assignment0 - The Knights Tour
------------------------------

SETUP
-----

Run 'make' in the assignment0 directory to build the project.


Running Source Code
-------------------

All 1728 Tour can be run using the ./assignment0 command. The source code is located inside of the tour.c file.



Notes
-----

No ChangeLog file was necessary for this assignment.
