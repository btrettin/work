## Assignment0 - The Knights Tour

## SETUP

Run 'make' inside the trettin_benjamin.assignment-0 directory to build the project.

## Running Source Code

All 1728 Tours can be run using the './tour' command. The source code is located inside of the tour.c file.

## Notes

No ChangeLog file was necessary for this assignment.
