## Assignment 1.01 - Dungeon Generation

## SETUP

Run 'make' inside the trettin_benjamin.assignment-1.03 directory to build the project.

## Running Source Code

The three dungeon maps can be generated using the ./run command. The source code is located inside of the map.c, heap.c and dungeonGame.c files.

This should produce three dungeons maps.
1. Original Dungeon map
2. Distance to PC via Rooms and Cooridors.
3. Distance to PC through all tiles.  

## Notes

The CHANGELOG file shows all of my commits for this project up to this point.
